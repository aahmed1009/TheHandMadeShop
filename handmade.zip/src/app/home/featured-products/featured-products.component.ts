import { Component } from "@angular/core";

@Component({
  selector: "app-featured-products",
  templateUrl: "./featured-products.component.html",
  styleUrls: ["./featured-products.component.css"],
})
export class FeaturedProductsComponent {
  items = [
    {
      image: "https://source.unsplash.com/featured/?ring&sig=1",
      title: "Beautiful Handmade Ring 1",
      description: "A stunning handmade ring perfect for any occasion.",
      price: 599.99,
    },
    {
      image: "https://source.unsplash.com/featured/?bracelet&sig=1",
      title: "Elegant Silver Bracelet",
      description: "A stylish silver bracelet to complement your outfit.",
      price: 699.99,
    },
    {
      image: "https://source.unsplash.com/featured/?earring&sig=1",
      title: "Beautiful Handmade Earring 1",
      description: "Handcrafted earrings that add elegance to your look.",
      price: 399.99,
    },
    {
      image: "https://source.unsplash.com/featured/?ring&sig=2",
      title: "Elegant Silver Ring",
      description: "A classic silver ring that never goes out of style.",
      price: 899.99,
    },
    {
      image: "https://source.unsplash.com/featured/?bracelet&sig=2",
      title: "Classic Gold Bracelet",
      description: "An exquisite gold bracelet with timeless appeal.",
      price: 1199.99,
    },
    {
      image: "https://source.unsplash.com/featured/?earring&sig=2",
      title: "Elegant Silver Earring",
      description: "Sophisticated silver earrings for a polished look.",
      price: 699.99,
    },
  ];

  constructor() {}

  ngOnInit(): void {}
}
