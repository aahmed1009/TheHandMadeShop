import { Component } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { ApiService } from "services/api.service";

@Component({
  selector: "app-products-details",
  templateUrl: "./products-details.component.html",
  styleUrls: ["./products-details.component.css"],
})
export class ProductsDetailsComponent {
  users: any = [];
  constructor(private route: ActivatedRoute, private api: ApiService) {}

  ngOnInit(): void {
    // let id = this.route.snapshot.paramMap.get("id");
    // console.log(id);
    // let cond = "id=" + id;
    // this.api.get_UsersDetails(cond).subscribe({
    //   next: (data: any) => {
    //     console.log(data[0]);
    //     this.users = data[0];
    //   },
    // });
    //
  }
}
