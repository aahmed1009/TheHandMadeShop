import { Component } from "@angular/core";
import { ApiService } from "services/api.service";

@Component({
  selector: "app-our-products",
  templateUrl: "./our-products.component.html",
  styleUrls: ["./our-products.component.css"],
})
export class OurProductsComponent {
  items = [
    {
      id: 1,
      image: "https://source.unsplash.com/featured/?ring&sig=1",
      title: "Beautiful Handmade Ring 1",
      description: "A stunning handmade ring perfect for any occasion.",
      price: 599.99,
    },
    {
      id: 2,
      image: "https://source.unsplash.com/featured/?bracelet&sig=1",
      title: "Elegant Silver Bracelet",
      description: "A stylish silver bracelet to complement your outfit.",
      price: 699.99,
    },
    {
      id: 3,
      image: "https://source.unsplash.com/featured/?earring&sig=1",
      title: "Beautiful Handmade Earring 1",
      description: "Handcrafted earrings that add elegance to your look.",
      price: 399.99,
    },
    {
      id: 4,
      image: "https://source.unsplash.com/featured/?ring&sig=2",
      title: "Elegant Silver Ring",
      description: "A classic silver ring that never goes out of style.",
      price: 899.99,
    },
    {
      id: 5,
      image: "https://source.unsplash.com/featured/?bracelet&sig=2",
      title: "Classic Gold Bracelet",
      description: "An exquisite gold bracelet with timeless appeal.",
      price: 1199.99,
    },
    {
      id: 6,
      image: "https://source.unsplash.com/featured/?earring&sig=2",
      title: "Elegant Silver Earring",
      description: "Sophisticated silver earrings for a polished look.",
      price: 699.99,
    },
    {
      id: 7,
      image: "https://source.unsplash.com/featured/?ring&sig=3",
      title: "Stylish Diamond Ring",
      description: "A glamorous ring with sparkling diamonds.",
      price: 1999.99,
    },
    {
      id: 8,
      image: "https://source.unsplash.com/featured/?bracelet&sig=3",
      title: "Vintage Pearl Bracelet",
      description: "A beautiful bracelet with vintage pearls.",
      price: 899.99,
    },
    {
      id: 9,
      image: "https://source.unsplash.com/featured/?earring&sig=3",
      title: "Vintage Pearl Earring",
      description: "Classic earrings with a vintage pearl design.",
      price: 599.99,
    },
  ];
  users: any = [];

  constructor(private api: ApiService) {}

  ngOnInit(): void {
    this.api.get_Users().subscribe({
      next: (data: any) => {
        console.log(data);
        this.users = data; // Assign the response directly to the users array
      },
      error: (err: any) => {
        console.error("Error fetching users", err);
      },
    });
  }
  deleteUser(userId: number): void {
    this.api.delete_user(userId).subscribe({
      next: (response: any) => {
        console.log("User deleted:", response);
        this.users = this.users.filter((user: any) => user.id !== userId); // Remove the deleted user from the users array
      },
      error: (err: any) => {
        console.error("Error deleting user:", err);
      },
    });
  }
  viewDetails(itemId: number): void {
    //  d view component with item ID
  }
}
