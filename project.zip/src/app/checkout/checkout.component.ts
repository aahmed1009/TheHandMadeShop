import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from 'services/api.service';
import { CartService } from 'services/cart.service';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css'],
})
export class CheckoutComponent {
  cartItems: any[] = [];
  totalAmount: number = 0;

  constructor(
    private cartService: CartService,
    private apiService: ApiService,
    private router: Router
  ) {
    this.cartItems = this.cartService.getCartItems();
    this.totalAmount = this.cartItems.reduce(
      (sum, item) => sum + item.price * item.quantity,
      0
    );
  }

  placeOrder(): void {
    const order = {
      user_id: 1, // Replace with dynamic user id
      total_amount: this.totalAmount,
      items: this.cartItems,
    };

    this.apiService.placeOrder(order).subscribe({
      next: (res) => {
        console.log('Order placed successfully', res);
        this.cartService.clearCart();
        this.router.navigate(['/orders']);
      },
      error: (err) => {
        console.error('Error placing order', err);
      },
    });
  }
}
