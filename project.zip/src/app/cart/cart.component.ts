import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from 'services/api.service';
import { AuthService } from 'services/auth.service';
import { CartService } from 'services/cart.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
})
export class CartComponent {
  cartItems: any[] = [];

  constructor(
    private cartService: CartService,
    private apiService: ApiService,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.cartItems = this.cartService.getCartItems();
  }

  removeItem(productId: number): void {
    this.cartService.removeFromCart(productId);
    this.cartItems = this.cartService.getCartItems();
  }

  checkout(): void {
    const userId = this.authService.getUserId();
    if (userId === null) {
      alert('User not logged in');
      return;
    }

    const order = {
      user_id: userId,
      items: this.cartItems.map((item) => ({
        product_id: item.id,
        quantity: item.quantity,
        price: item.price,
      })),
      total_amount: this.cartItems.reduce(
        (sum, item) => sum + item.price * item.quantity,
        0
      ),
    };

    this.apiService.createOrder(order).subscribe({
      next: (res) => {
        console.log('Order created successfully', res);
        this.cartService.clearCart();
        this.router.navigate(['/dashboard/orders-management']);
      },
      error: (err) => {
        console.error('Error creating order', err);
      },
    });
  }
}
