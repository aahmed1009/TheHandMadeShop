import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class CartService {
  private cartItems: any[] = [];

  constructor() {}

  getCartItems(): any[] {
    return this.cartItems;
  }

  addToCart(product: any, quantity: number): void {
    const existingItem = this.cartItems.find(
      (item) => item.product_id === product.id
    );

    if (existingItem) {
      existingItem.quantity += quantity;
    } else {
      this.cartItems.push({ ...product, quantity });
    }
  }

  removeFromCart(productId: number): void {
    this.cartItems = this.cartItems.filter(
      (item) => item.product_id !== productId
    );
  }

  clearCart(): void {
    this.cartItems = [];
  }
}
